﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppNominaoo01
{
    public class Empleado
    {
        public string identificacion;

        public string nombre;

        public double horasTrabajadas;

        public double sueldoXHora;

    }
}
